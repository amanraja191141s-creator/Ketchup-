# Release limitations — v98.63

- No physical Android device installation or screenshot comparison was performed in this environment.
- No real-device performance, memory or battery benchmark was performed; “lag-free” cannot be certified from source tests alone.
- A debug APK is produced by the supplied GitHub Actions workflow when run with Android SDK access; this ZIP itself is source, not a prebuilt APK.
- Existing user data from older installed versions is not automatically erased by this source cleanup.
