# Micro-level cleanup audit — v98.63

## Findings and changes

1. **Stale release documents:** the root contained more than 100 accumulated historical notes, audits, research summaries and QA reports. These were not runtime app screens. Removed old copies and retained the current README, changelog, audit, QA and limitations files.
2. **Duplicate workflows:** multiple old versioned workflow YAML files were shipped alongside the canonical workflow. Removed duplicate copies; `.github/workflows/main.yml` is canonical.
3. **Unused design assets:** removed obsolete visual mockups and an old inventory not used by the runtime or regression tests.
4. **Promotional header copy:** removed “SMART • POWERFUL • PREMIUM” and simplified the browser/document title. The app name remains “SA Calculator”.
5. **History action wording:** retained “Clear Unlocked History” because the action deliberately preserves protected entries; this label accurately describes its behavior.
6. **Release identity:** synchronized package, manifest, HTML, runtime, service worker and workflow to `1.98.63-v98.63`, Android versionCode `1098063`.

## Preserved

- Calculator and scientific calculator screens and calculation engine.
- History and favorites.
- Tools, unit converters and currency converter.
- Settings, theme controls, localization and accessibility labels.
- Capacitor Android build configuration and source regression tests.

## Scope boundary

This is a source/archive cleanup and text correction. It does not claim a physical-device test, APK installation, forensic data removal, performance benchmark or security certification.


No private Cloudflare Worker is shipped by this project. No private API endpoint is claimed.
