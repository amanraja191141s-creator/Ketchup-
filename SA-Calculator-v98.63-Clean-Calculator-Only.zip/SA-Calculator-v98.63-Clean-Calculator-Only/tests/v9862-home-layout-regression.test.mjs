import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');
test('v98.63 Home has no top header and uses its freed space for the display', () => {
 const html=read('index.html'), css=read('assets/css/rebuild-v98.62.css'), builder=read('scripts/prepare-android-web.mjs');
 assert.match(html,/rebuild-v98\.62\.css/); assert.match(builder,/rebuild-v98\.62\.css/);
 assert.match(css,/#app-container:has\(#screen-calc\.active\) > \.app-header\{display:none/);
 assert.match(css,/#screen-calc\.active>\.calc-display\{flex:1 1 0/);
 assert.match(css,/#screen-calc\.active>\.main-keypad\{flex:0 0 52%/);
});
test('v98.63 navigation order is Home, Tools, History, Favorite, Settings',()=>{
 const html=read('index.html'), nav=html.match(/<nav class="bottom-navigation"[\s\S]*?<\/nav>/)?.[0]||'';
 const values=[...nav.matchAll(/data-bottom-nav="([^"]+)"/g)].map(x=>x[1]);
 assert.deepEqual(values,['calc','tools','history','favorites','settings']);
 assert.match(nav,/<span>Favorite<\/span>/); assert.match(read('assets/css/rebuild-v98.62.css'),/grid-template-columns:repeat\(5,minmax\(0,1fr\)\)/);
});
test('v98.63 keypad has compact numeric and operator sizing',()=>{
 const css=read('assets/css/rebuild-v98.62.css');
 assert.match(css,/key-btn\{min-height:0!important;height:100%!important;font-size:clamp\(17px/);
 assert.match(css,/key-btn\.op-key\{font-size:clamp\(19px/);
});
test('v98.63 build identities and cache are refreshed',()=>{
 const pkg=JSON.parse(read('package.json')),manifest=JSON.parse(read('manifest.webmanifest')),html=read('index.html'),sw=read('service-worker.js'),wf=read('.github/workflows/main.yml');
 assert.equal(pkg.version,'1.98.63-v98.63'); assert.equal(manifest.version,pkg.version);
 assert.match(html,/1\.98\.63-v98\.63/); assert.match(sw,/sa-calculator-v98-63-clean-copy-v9863/);
 assert.match(wf,/SA_EXPECTED_VERSION: '1\.98\.63-v98\.63'/); assert.match(wf,/versionCode='1098063'/);
});
